package com.fawaz.notesapp.data.entity

enum class Priority {
    HIGH,
    MEDIUM,
    LOW
}