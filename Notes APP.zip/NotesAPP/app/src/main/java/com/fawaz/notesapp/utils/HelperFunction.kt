package com.fawaz.notesapp.utils

import android.content.Context
import android.view.View
import android.widget.AdapterView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import com.fawaz.notesapp.R

object HelperFunction {
    fun spinnerListener(context: Context?, priorityIndicator : CardView): AdapterView.OnItemSelectedListener =
        object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                context?.let {
                    when(position){
                        0 -> {
                            //Untuk menentukan warna
                            val pink = ContextCompat.getColor(it, R.color.pink)
                            priorityIndicator.setCardBackgroundColor(pink)
                        }
                        1 -> {
                            val yellow = ContextCompat.getColor(it, R.color.yellow)
                            priorityIndicator.setCardBackgroundColor(yellow)
                        }
                        2 -> {
                            val green = ContextCompat.getColor(it, R.color.green)
                            priorityIndicator.setCardBackgroundColor(green)
                        }
                    }
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }
}